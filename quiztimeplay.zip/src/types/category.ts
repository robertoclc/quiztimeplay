export interface Category {

    id: string;

    slug: string;

    title: string;

    h1: string;

    description: string;

    seoTitle: string;

    seoDescription: string;

    intro: string;

    icon: string;

}